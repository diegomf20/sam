<script type="text/javascript" src="../vendor/framewoks/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="../vendor/js/panel.js"></script>
<script type="text/javascript" src="../vendor/alertifyjs/alertify.min.js"></script>
<script type="text/javascript" src="../vendor/framewoks/vue.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="//cdn.datatables.net/responsive/2.2.1/js/dataTables.responsive.min.js"></script>
