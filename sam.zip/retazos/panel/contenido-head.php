<div class="row">
  <div class="contenido-head">
    <button id="menu-boton" class="head-boton">
      <i class="fa fa-bars" aria-hidden="true"></i>
    </button>
    <div class="head-icon">
      <i class="fa fa-cube"></i>
    </div>
    <div class="head-titulo"><?php echo $pagina ?></div>
    <a class="head-salir" href="cerrar.php">
      <i class="fa fa-sign-out" aria-hidden="true"></i> Salir
    </a>
  </div>
</div>
