<button type="button" name="button" class="rango rango-<?php echo $rango ?>">
  <?php echo $rango ?> <?php if ($inversionista['renovacion']>0) {
    echo " - REN";
  } ?>
</button>
