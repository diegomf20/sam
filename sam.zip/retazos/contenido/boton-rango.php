<button type="button" name="button" class="rango rango-<?php echo $rango ?>">
  <?php echo $rango ?>
</button>
