<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<!--diseño-->
<link rel="stylesheet" href="vendor/framewoks/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="vendor/css/panel.css">
<link rel="stylesheet" href="vendor/css/forms.css">
<link rel="stylesheet" href="vendor/alertifyjs/css/alertify.min.css">
<!--fuentes-->
<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto:400,700,300">
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
<!--Tablas responsivas DataTable-->
<link rel="stylesheet" href="//cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/responsive/2.2.1/css/responsive.dataTables.min.css">
<!---->
